/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package finalproject;

import java.util.ArrayList;

/**
 *
 * @author Arjie
 */
public class MainC {
    public class adminPass{
    
        String username;
        String password;
         String ADMIN_USERNAME = "admin";
         String ADMIN_PASSWORD = "1234";
    }
  
    
// Student class
public class Student { 
    int studentId;
    String firstName;
    String lastName;
    String course;
    String section;

    public Student(int studentId, String firstName, String lastName, String course, String section) {
        this.studentId = studentId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.course = course;
        this.section = section;
    }
       

        public int getStudentId() {
            return studentId;
        }

        public void setStudentId(int studentId) {
            this.studentId = studentId;
        }

        public String getFirstName() {
            return firstName;
        }

        public void setFirstName(String firstName) {
            this.firstName = firstName;
        }

        public String getLastName() {
            return lastName;
        }

        public void setLastName(String lastName) {
            this.lastName = lastName;
        }

        public String getCourse() {
            return course;
        }

        public void setCourse(String course) {
            this.course = course;
        }

        public String getSection() {
            return section;
        }

        public void setSection(String section) {
            this.section = section;
        }

      
    
    
    

    
    
    

   
}

public void displayStudents() {
        for (Student student : studentList) {
            System.out.println("Student ID: " + student.getStudentId());
            System.out.println("Name: " + student.getFirstName() + " " + student.getLastName());
            System.out.println("Course: " + student.getCourse());
            System.out.println("Section: " + student.getSection());
            System.out.println("-------------------");
        }
    }
// Data Storage in MainC 
    private ArrayList<Student> studentList = new ArrayList<>();

    // Method to add students
    public void addStudent(Student student) {
        studentList.add(student);
    }
    
    
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new LogIndesign().setVisible(true);
    }
    
}

