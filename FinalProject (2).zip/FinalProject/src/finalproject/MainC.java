/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package finalproject;

/**
 *
 * @author Arjie
 */
public class MainC {
    public class adminPass{
    
        String username;
        String password;
         String ADMIN_USERNAME = "admin";
         String ADMIN_PASSWORD = "1234";
    }
    public class Student {
     int studentId;
     String firstName;
     String lastName;
     String course;
     String section;

    
    public Student(int studentId, String firstName, String lastName, String course, String section) {
            this.studentList = new Student[50];
        this.studentId = studentId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.course = course;
        this.section = section;
        
    
    }

        Student() {
            this.studentList = new Student[50];
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        public int getStudentId() {
            return studentId;
        }

        public void setStudentId(int studentId) {
            this.studentId = studentId;
        }

        public String getFirstName() {
            return firstName;
        }

        public void setFirstName(String firstName) {
            this.firstName = firstName;
        }

        public String getLastName() {
            return lastName;
        }

        public void setLastName(String lastName) {
            this.lastName = lastName;
        }

        public String getCourse() {
            return course;
        }

        public void setCourse(String course) {
            this.course = course;
        }

        public String getSection() {
            return section;
        }

        public void setSection(String section) {
            this.section = section;
        }

        public Student[] getStudentList() {
            return studentList;
        }

        public void setStudentList(Student[] studentList) {
            this.studentList = studentList;
        }
    
    Student [] studentList;
    
    

   
}
    
    
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new LogIndesign().setVisible(true);
    }
    
}
