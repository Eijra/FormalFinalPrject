package attendancemonitoring;

import java.awt.*;
import java.awt.event.*;
import javax.swing.BoxLayout;
import javax.swing.JPasswordField;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class TheAttendanceMonitoringSystem 
{
    private JSONArray studentDB = new org.json.simple.JSONArray();
    
    private javax.swing.JPanel registrationPanel;
    private javax.swing.JPanel attendancePanel;
    private javax.swing.JPanel searchPanel;
    private javax.swing.JPanel reportPanel;
    private javax.swing.JPanel aboutPanel;
    
    private static Frame mainFrame;
    
    
    
    //The Public Method for creating the FRAMES
    public static void main(String[] args) 
    {
        TheAttendanceMonitoringSystem theAttendanceMonitoringSystem = new TheAttendanceMonitoringSystem();
        
        //Creating the LOG IN FRAME
        Frame loginFrame = new Frame("Log-In");
        loginFrame.setSize(1000,800);
        loginFrame.setLayout(null);
        loginFrame.setVisible(true);
                
        new TheAttendanceMonitoringSystem().LoginPanel(loginFrame);
        
        //eventlistener for CLOSING THE LOG IN FRAME
        loginFrame.addWindowListener(new WindowAdapter()  {
            public void windowClosing(WindowEvent e){
                loginFrame.dispose(); 
            } 
        });  
        
        //Creating the MAIN FRAME
        mainFrame = new Frame("Java Attendance Monitoring System - JAMS");
        mainFrame.setSize(1000,800);
        mainFrame.setLayout(null);
        mainFrame.setVisible(false);
        
        mainFrame.add(theAttendanceMonitoringSystem.RegistrationPanel());
        mainFrame.add(theAttendanceMonitoringSystem.AttendancePanel());
        mainFrame.add(theAttendanceMonitoringSystem.SearchPanel());
        mainFrame.add(theAttendanceMonitoringSystem.ReportPanel());
        mainFrame.add(theAttendanceMonitoringSystem.AboutPanel());
        mainFrame.add(theAttendanceMonitoringSystem.MenuPanel(theAttendanceMonitoringSystem));
        
        //eventlistener for CLOSING THE MAIN FRAME
        mainFrame.addWindowListener(new WindowAdapter()  {
            public void windowClosing(WindowEvent e){
                mainFrame.dispose(); 
            } 
        }); 
    }
    
    //The Private Method for the LOG IN PANEL
    private void LoginPanel(Frame frame) {
        //Creating the Log In Panel and its components
        Label LabelUserName = new Label("Username: ");
        Label LabelPassWord = new Label("Password: ");
        TextField TypeUserName = new TextField();
        JPasswordField TypePassword = new JPasswordField();
        Button LogInButton = new Button("Confirm");

        //Correct Credentials
        String CorrectUserName = "admin";
        String CorrectPassWord = "1234";

        //Adding the components of the Log In Panel
        frame.add(LabelUserName);
        frame.add(TypeUserName);
        frame.add(TypePassword);
        frame.add(LabelPassWord);
        frame.add(LogInButton);

        //Setting the appearance of the components
        LabelUserName.setVisible(true);
        LabelUserName.setBounds(400,350,200,25);
        TypeUserName.setVisible(true);
        TypeUserName.setBounds(400,375,200,25);
        LabelPassWord.setVisible(true);
        LabelPassWord.setBounds(400,400,200,30);
        TypePassword.setVisible(true);
        TypePassword.setBounds(400,425,200,30);
        LogInButton.setVisible(true);
        LogInButton.setBounds(450,500,100,30);

        //Verifying the Inputted Details
        LogInButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Label LoginLabel = new Label();
                LoginLabel.setBounds(400,450,200,30);
                String InputtedUserName = TypeUserName.getText();
                String InputtedPassWord = TypePassword.getText();

                if(InputtedUserName.equals(CorrectUserName) && InputtedPassWord.equals(CorrectPassWord))
                {
                    LoginLabel.setText("Correct");
                    frame.dispose();
                    mainFrame.setVisible(true);
                }
                else
                {
                    LoginLabel.setText("Incorrect credentials");
                    LoginLabel.setVisible(true);
                    frame.add(LoginLabel);
                    TypeUserName.setText("");
                    TypePassword.setText("");
                }
            }
        });

    }
    
    // The Private Method for the MENU PANEL
    private Panel MenuPanel(TheAttendanceMonitoringSystem theAttendanceMonitoringSystem){
        Panel container = new Panel();
        container.setLayout(new GridLayout(0, 1, 0, 10)); 

        Button RegistrationButton = new Button("Registration");
        Button CheckAttendanceButton = new Button("Check Attendance");
        Button SearchAttendanceButton = new Button("Search Attendance");
        Button AttendanceReportButton = new Button("Report Summary");
        Button AboutButton = new Button("About the Program");

        container.add(RegistrationButton);
        container.add(CheckAttendanceButton);
        container.add(SearchAttendanceButton);
        container.add(AttendanceReportButton);
        container.add(AboutButton);
        
        RegistrationButton.addActionListener(new ActionListener() {
          @Override
            public void actionPerformed(ActionEvent e) {
                CloseAllPanels(theAttendanceMonitoringSystem);
                theAttendanceMonitoringSystem.registrationPanel.setVisible(true);
            }
        });
        CheckAttendanceButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CloseAllPanels(theAttendanceMonitoringSystem);
                theAttendanceMonitoringSystem.attendancePanel.setVisible(true);
            }
        });
        SearchAttendanceButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CloseAllPanels(theAttendanceMonitoringSystem);
                theAttendanceMonitoringSystem.searchPanel.setVisible(true);
            }
        });
        AttendanceReportButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CloseAllPanels(theAttendanceMonitoringSystem);
                theAttendanceMonitoringSystem.reportPanel.setVisible(true);
            }
        });
        AboutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CloseAllPanels(theAttendanceMonitoringSystem);
                theAttendanceMonitoringSystem.aboutPanel.setVisible(true);
            }
        });
        
        container.setBounds(30, 60, 360, 670); 


        return container;
    }
    
    // PANEL CLOSE
    private void CloseAllPanels(TheAttendanceMonitoringSystem theAttendanceMonitoringSystem) {
        theAttendanceMonitoringSystem.registrationPanel.setVisible(false);
        theAttendanceMonitoringSystem.attendancePanel.setVisible(false);
        theAttendanceMonitoringSystem.searchPanel.setVisible(false);
        theAttendanceMonitoringSystem.attendancePanel.setVisible(false);
        theAttendanceMonitoringSystem.reportPanel.setVisible(false);
        theAttendanceMonitoringSystem.aboutPanel.setVisible(false);
    }

    // REGISTRATION PANEL   
    private javax.swing.JPanel RegistrationPanel() {
        javax.swing.JPanel container = new javax.swing.JPanel();
        container.setBounds(420, 200, 550, 400); 
        container.setLayout(new BoxLayout(container, 1));
        
        Label LabelStudentId = new Label("StudentId: ");
        TextField TypeStudentId = new TextField();
        Label LabelFirstName = new Label("First Name: ");
        TextField TypeFirstName = new TextField();
        Label LabelLastName = new Label("Last Name: ");
        TextField TypeLastName = new TextField();
        Label LabelCourse = new Label("Course: ");
        TextField TypeCourse = new TextField();
        Label LabelSection = new Label("Section: ");
        TextField TypeSection = new TextField();
        
        Button ButtonRegister = new Button("Register");
        
        container.add(LabelStudentId);
        container.add(TypeStudentId);
        container.add(LabelFirstName);
        container.add(TypeFirstName);
        container.add(LabelLastName);
        container.add(TypeLastName);
        container.add(LabelCourse);
        container.add(TypeCourse);
        container.add(LabelSection);
        container.add(TypeSection);
        container.add(ButtonRegister);
        
        ButtonRegister.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                int studentID = Integer.parseInt(TypeStudentId.getText());
                String firstName = TypeFirstName.getText();
                String lastName = TypeLastName.getText();
                String course = TypeCourse.getText();
                String section = TypeSection.getText();
                
                
                if (!checkIfStudentIdExist(studentID)) {
                    JSONObject student = new org.json.simple.JSONObject();
                    student.put("studentId", studentID);
                    student.put("firstName", TypeFirstName.getText());
                    student.put("lastName", TypeLastName.getText());
                    student.put("section", TypeSection.getText());
                    student.put("course", TypeCourse.getText());
                    
                    TypeStudentId.setText("");
                    TypeFirstName.setText("");
                    TypeLastName.setText("");
                    TypeSection.setText("");
                    TypeCourse.setText("");
                    
                    System.out.println(studentID);
                    System.out.println(TypeFirstName);
                    System.out.println(TypeLastName);
                    System.out.println(TypeSection);
                    System.out.println(TypeCourse);
                 
                    studentDB.add(student);
                }
        }});
        
        container.setVisible(false);
        registrationPanel = container;
        return container;
    }

        // ATTENDANCE PANEL
        private javax.swing.JPanel AttendancePanel() {
        javax.swing.JPanel container = new javax.swing.JPanel();
        container.setBounds(420, 60, 550, 670);
        container.setLayout(null); // Consider using a layout manager

        Label dateLabel = new Label("Date (YYYY-MM-DD): ");
        dateLabel.setBounds(20, 20, 150, 25);
        container.add(dateLabel);

        TextField dateField = new TextField();
        dateField.setBounds(170, 20, 150, 25);
        container.add(dateField);

        Button confirmButton = new Button("Confirm");
        confirmButton.setBounds(340, 20, 100, 25);
        container.add(confirmButton);

        // Load initial attendance data (if you have a stored file)
        loadAttendanceData(); 

        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String date = dateField.getText();

                // Add date-specific attendance data to JSON (structure up to you)
                JSONObject attendanceData = getAttendanceDataForDate(date);
                // ... Add student attendance marking logic ... (not included in this example)

                storeAttendanceData(date, attendanceData); 
            }
        });

        container.setVisible(false);
        attendancePanel = container;
        return container;
    }

// Placeholder JSON methods (you'll need to implement the actual logic)
private JSONObject getAttendanceDataForDate(String date) {
    // ... Logic to fetch attendance data if it exists for the date 
}

private void storeAttendanceData(String date, JSONObject attendanceData) { 
    // ... Logic to save/update attendance data in a JSON structure or file
}

private void loadAttendanceData() {
    // ... Logic to load existing JSON attendance file
}
    
    // SEARCH PANEL
    private javax.swing.JPanel SearchPanel() {
        javax.swing.JPanel container = new javax.swing.JPanel();
        container.setBounds(420, 60, 550, 670);
        container.add(new Label("Search Panel"));
        
        container.setVisible(false);
        searchPanel = container;
        return container;
    }
    
    // REPORT PANEL
    private javax.swing.JPanel ReportPanel() {
        javax.swing.JPanel container = new javax.swing.JPanel();
        container.setBounds(420, 60, 550, 670);
        container.add(new Label("Report Panel")); 
        
        container.setVisible(false);
        reportPanel = container;
        return container;
    }

    // ABOUT PANEL
    private javax.swing.JPanel AboutPanel() {
        javax.swing.JPanel container = new javax.swing.JPanel();
        container.setBounds(420, 60, 550, 670);
        container.add(new Label("About Panel")); 
        
        container.setVisible(false);
        aboutPanel = container;
        return container;
    }
    
    private boolean checkIfStudentIdExist(int studentId) {
        boolean exists = false;
        for (int i = 0; i < studentDB.size(); i++) {
                JSONObject obj = new org.json.simple.JSONObject();
                    obj = (JSONObject) studentDB.get(i);
                    if(obj.get("studentId").equals(studentId))
                    {
                        exists = true;
                        break;
                    }
        }

        return exists;
    }
}